$(document).ready(function() {
	$("#eats-marketplace").click(function() {
		window.location.href = "http://wesleyan.cafebonappetit.com/cafe/the-marketplace-at-usdan/";
	});

	$("#eats-summerfields").click(function() {
		window.location.href = "http://wesleyan.cafebonappetit.com/cafe/summerfields/";
	});

	$("#eats-sc").click(function() {
		window.location.href = "http://wesleying.org/author/star-and-crescent/";
	});
})